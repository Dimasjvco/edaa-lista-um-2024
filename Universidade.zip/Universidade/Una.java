public class Una {
    public static void main(String[] args) {
        
        Aluno aluno = new Aluno("Maria Eduarda", 25, "12345678912");
        Professor professor = new Professor("Daniel Paiva", 31, "12121212", "Graduação e Pós Graduação");
        Universidade universidade = new Universidade("UNi BH", "Rua dos Canarios", "12121212");
        Disciplina disciplina = new Disciplina();
        System.out.println("Professor: " + professor.Getnome());
        System.out.println("Universidade: " + universidade.Getnome());
        disciplina.lancarPresencaDiariaAluno(7, aluno);
    }
}
