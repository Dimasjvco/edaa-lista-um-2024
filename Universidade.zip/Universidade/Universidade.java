public class Universidade {
    private String nome;
    private String CNPJ;
    private String endereco;

    public Universidade(String nome, String CNPJ, String endereco) {
        this.nome = nome;
        this.endereco = endereco;
        this.CNPJ = CNPJ;
    }

    public String Getnome(){
        return nome;
    }
 
    public String GetEndereco(){
        return endereco;
    }
    
    public String GetCNPJ(){
        return CNPJ;
    }
}
