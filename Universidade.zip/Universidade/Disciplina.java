import java.text.MessageFormat;

public class Disciplina {

    private String nome;
    private double presencaDiaria;
    private Aluno aluno;
    private String prova;


    public void lancarPresencaDiariaAluno(double qtdeAulaVista, Aluno aluno){
        presencaDiaria = qtdeAulaVista;
        System.out.println(MessageFormat.format("Aluno(a) {0} presente em aula", aluno.GetNome()));
    }


    public String getNome() {
        return nome;
    }


    public void setNome(String nome) {
        this.nome = nome;
    }


    public double getPresencaDiaria() {
        return presencaDiaria;
    }


    public void setPresencaDiaria(double presencaDiaria) {
        this.presencaDiaria = presencaDiaria;
    }


    public Aluno getAluno() {
        return aluno;
    }


    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }


    public String getProva() {
        return prova;
    }


    public void setProva(String prova) {
        this.prova = prova;
    }
}