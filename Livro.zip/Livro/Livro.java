public class Livro {
    public Main(String titulo, String autor, String assunto, int qtdePaginas, String editora, String iSBN) {
        this.titulo = titulo;
        this.autor = autor;
        this.assunto = assunto;
        this.QtdePaginas = qtdePaginas;
        this.editora = editora;
        this.ISBN = iSBN;
    }

    private String titulo;
    public String GetTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    private String autor;
    public String GetAutor() {
        return autor;
    }
    public void setAutor(String autor) {
        this.autor = autor;
    }

    private String assunto;
    public String GetAssunto() {
        return assunto;
    }
    public void setAssunto(String assunto) {
        this.assunto = assunto;
    }
    
    private int QtdePaginas;
    public int GetQtdePaginas() {
        return QtdePaginas;
    }
    public void setQtdePaginas(int QtdePaginas) {
        this.QtdePaginas = QtdePaginas;
    }

    private String editora;
    public String GetEditora() {
        return editora;
    }
    public void setEditora(String editora) {
        this.editora = editora;
    }
    
    private String ISBN;
    public String GetISBN() {
        return ISBN;
    }
    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }
}

