public class Livraria {
    public static void main(String[] args) {
        Livro livro = new Livro();

        livro.setTitulo("Percy Jackson");
        System.out.println("Titulo:"); System.out.println(livro.GetTitulo());

        livro.setAutor("Laysla");
        System.out.println("Autor:"); System.out.println(livro.GetAutor());

        livro.setAssunto("Deuses");
        System.out.println("Assunto:"); System.out.println(livro.GetAssunto());

        livro.setEditora("Biro biro");
        System.out.println("Editora:"); System.out.println(livro.GetEditora());

        livro.setISBN("978 85  333  0227  3");
        System.out.println("ISBN:"); System.out.println(livro.GetISBN());
                
        livro.setQtdePaginas(1860);
        System.out.println("Quantidade de Paginas:"); System.out.println(livro.GetQtdePaginas());

    }
}
