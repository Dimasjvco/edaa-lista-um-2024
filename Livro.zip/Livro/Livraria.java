public class Livraria {
    public static void main(String[] args) {
        Livro livro = new Livro();

        livro.setTitulo("Percy Jackson");
        System.out.println("Titulo: " + livro.GetTitulo());

        livro.setAutor("Laysla");
        System.out.println("Autor: " + livro.GetAutor());

        livro.setAssunto("Deuses");
        System.out.println("Assunto: " + livro.GetAssunto());

        livro.setEditora("Biro biro");
        System.out.println("Editora: " + livro.GetEditora());

        livro.setISBN("978 85  333  0227  3");
        System.out.println("ISBN: " + livro.GetISBN());
                
        livro.setQtdePaginas(1860);
        System.out.println("Quantidade de Paginas: " + livro.GetQtdePaginas());

    }
}
