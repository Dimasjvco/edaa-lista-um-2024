public class Pessoa {
    public static void main(String[] args) {
        Dados dados = new Dados();

        dados.setNome("João Victor");
        System.out.println("Nome: " + dados.GetNome());

        dados.setCpf("111.222.333.44");
        System.out.println("CPF: " + dados.GetCpf());

        dados.setIdade(21);
        System.out.println("Idade: " + dados.GetIdade());

        dados.setAltura(1.70);
        System.out.println("Altura: " + dados.GetAltura());

        dados.setPeso(55.50);
        System.out.println("Peso: " + dados.GetPeso());

    }
    
}
