public class Dados {
    public Main(String nome, int cpf, int idade, Double altura, double peso) {
        this.nome = nome;
        this.cpf = cpf;
        this.idade = idade;
        this.altura = altura;
        this.peso = peso;
    }
    public String nome;
    public String GetNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String cpf;
    public String GetCpf() {
        return cpf;
    }
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public int idade;
    public int GetIdade() {
        return idade;
    }
    public void setIdade(int idade) {
        this.idade = idade;
    }

    public Double altura;
    public Double GetAltura() {
        return altura;
    }

    public void setAltura(Double altura) {
        this.altura = altura;
    }

    public double peso;
    public Double GetPeso() {
        return peso;
    }

    public void setPeso(Double peso) {
        this.peso = peso;
    }


}
