public class Programa {
    public static void main(String[] args) {
        Cachorro dog = new Cachorro();
        dog.setId(1);
        dog.setNome("Trovão");
        dog.setIdade(5);
        System.out.println(dog.getNome());
        dog.latir();

    }

}
